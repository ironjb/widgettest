var ltjQuery = jQuery.noConflict(true);
var LoanTekManualContactWidget = (function () {
    function LoanTekManualContactWidget(options) {
        ltjQuery(function () {
            var widgetData = {
                "FileType": "SalesLead",
                "Reason": "FORM_VALUE_Comments",
                "Source": {
                    "Active": true,
                    "Alias": "LoanTek.com",
                    "Id": 44,
                    "SourceType": "LeadSource",
                    "Name": "LoanTek.com",
                    "SubName": "Contact-Us-Form"
                },
                "NotifyUserOfNewLead": true,
                "SendNewLeadInitialWelcomeMessage": true,
                "ClientDefinedIdentifier": "LTWSJavaScriptTimeStamp",
                "ClientId": 399,
                "Persons": [{
                        "PersonCategoryType": "Person",
                        "PersonType": "Primary",
                        "Addresses": [{
                                "State": "FORM_VALUE_State"
                            }],
                        "ContactMethods": [{
                                "ContactType": "Email",
                                "Address": "FORM_VALUE_Email"
                            }, {
                                "ContactType": "Phone",
                                "Number": "FORM_VALUE_Phone"
                            }],
                        "Assets": [{
                                "AssetType": "Job",
                                "CompanyName": "FORM_VALUE_Company"
                            }],
                        "FirstName": "FORM_VALUE_FName",
                        "LastName": "FORM_VALUE_LName"
                    }],
                "MiscData": [{
                        "Name": "AdditionalInformation",
                        "Value": "LEAVE_BLANK_FOR_NOW"
                    }]
            };
            ltjQuery('#LtcwContactWidgetForm').submit(function (event) {
                event.preventDefault();
                ltjQuery('#ltcwErrorMessageWrapper').hide(100);
                widgetData.Persons[0].FirstName = ltjQuery('#ltcwFirstName').val();
                widgetData.Persons[0].LastName = ltjQuery('#ltcwLastName').val();
                widgetData.Persons[0].ContactMethods[0].Address = ltjQuery('#ltcwEmail').val();
                widgetData.Persons[0].ContactMethods[1].Number = ltjQuery('#ltcwPhone').val();
                widgetData.Persons[0].Assets[0].CompanyName = ltjQuery('#ltcwCompany').val();
                widgetData.Persons[0].Addresses[0].State = ltjQuery('#ltcwState option:selected').val();
                widgetData.ClientDefinedIdentifier = 'LTWS' + new Date().getTime().toString();
                widgetData.Reason = ltjQuery('#ltcwComments').val();
                widgetData.MiscData[0].Value = '';
                var request = ltjQuery.ajax({
                    url: 'http://node-cors-server.herokuapp.com/simple-cors',
                    method: 'POST',
                    data: widgetData
                });
                request.done(function (result) {
                    ltjQuery('#LtcwContactWidgetForm').trigger('reset');
                    if (options.redirectUrl) {
                        window.location.assign(options.redirectUrl);
                    }
                    else if (options.successMessage) {
                        ltjQuery('#LtcwContactWidgetForm').hide(100, function () {
                            ltjQuery('#LtcwContactWidgetForm').remove();
                        });
                        ltjQuery('#ltcwSuccessMessageWrapper').show(100);
                        ltjQuery('#ltcwSuccessMessage').html(options.successMessage);
                    }
                });
                request.fail(function (error) {
                    window.console && console.log('errors', error);
                    ltjQuery('#ltcwErrorMessage').html(error);
                    ltjQuery('#ltcwErrorMessageWrapper').show(100);
                });
            });
        });
    }
    return LoanTekManualContactWidget;
}());
